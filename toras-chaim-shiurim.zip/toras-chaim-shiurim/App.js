import React from "react";

function App() {
  return (
    <div className="text-center text-xl p-10">
      Yeshiva Toras Chaim Shiurim Website – Setup Complete
    </div>
  );
}

export default App;
